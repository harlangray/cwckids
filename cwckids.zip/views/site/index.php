<?php
use yii\helpers\Html;
/* @var $this yii\web\View */

$this->title = 'CWC Children\'s Ministry';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Calvary Worship Center</h1>

        <p class="lead">Calvary Worship Center Children's Ministry</p>

        <?= Html::a('New Enrolment Form', ['parent-guardian/create'], ['class' => 'btn btn-lg btn-success']) ?>
       
        
    </div>

</div>
