<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\ChildSearch */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="child-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <?= $form->field($model, 'c_id') ?>

    <?= $form->field($model, 'c_parent_guardian_id') ?>

    <?= $form->field($model, 'c_first_name') ?>

    <?= $form->field($model, 'c_surname') ?>

    <?= $form->field($model, 'c_address') ?>

    <?php // echo $form->field($model, 'c_suburb') ?>

    <?php // echo $form->field($model, 'c_post_code') ?>

    <?php // echo $form->field($model, 'c_date_of_birth') ?>

    <?php // echo $form->field($model, 'c_gender') ?>

    <?php // echo $form->field($model, 'c_toilet_trained') ?>

    <?php // echo $form->field($model, 'c_grade') ?>

    <?php // echo $form->field($model, 'c_medical_conditions') ?>

    <?php // echo $form->field($model, 'c_medical_condition_note') ?>

    <?php // echo $form->field($model, 'c_behavioural_issue') ?>

    <?php // echo $form->field($model, 'c_behavioural_note') ?>

    <?php // echo $form->field($model, 'c_active') ?>

    <div class="form-group">
        <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton('Reset', ['class' => 'btn btn-default']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
