<?php

use yii\helpers\Html;

$baseUrl = yii::$app->urlManager->getBaseUrl();
?>
<div id="child_row_<?= $index; ?>">
    <div class="panel panel-primary">
        <div class="panel-heading" style="height: 50px;">
            <div style="float: left">
                <h3 class="panel-title"><i class="glyphicon glyphicon-certificate"></i>Child Details</h3>            
            </div>

            <a title="Remove" onclick="removechildRow('child_row_<?= $index ?>')" style="float: right;">
                <?php
                $options = '';
                echo Html::tag('div', Html::img($baseUrl . '/../images/close-me.png', $options), ['height' => '0px']);
                ?>
            </a>
        </div>
        <?php

        use kartik\builder\FormGrid;
        use kartik\builder\Form;
        use kartik\widgets\SwitchInput;

echo FormGrid::widget([
            'model' => $childMod,
            'form' => $form,
            'autoGenerateColumns' => true,
            'rows' => [
                [
                    'attributes' => [
                        "[$index]c_parent_guardian_id" => ['type' => Form::INPUT_TEXT, 'options' => ['placeholder' => '', 'class' => 'hidden'], 'label' => ''],
                    ],
                ],
                [
                    'attributes' => [
                        "[$index]c_first_name" => ['type' => Form::INPUT_TEXT, 'options' => ['placeholder' => '']],
                        "[$index]c_surname" => ['type' => Form::INPUT_TEXT, 'options' => ['placeholder' => '']],
                    ],
                ],
                [
                    'attributes' => [
                        "[$index]c_address" => ['type' => Form::INPUT_TEXT, 'options' => ['placeholder' => '']],
                        "[$index]c_suburb" => ['type' => Form::INPUT_TEXT, 'options' => ['placeholder' => '']],
                        "[$index]c_post_code" => ['type' => Form::INPUT_TEXT, 'options' => ['placeholder' => '']],
                    ],
                ],
                [
                    'attributes' => [
                        "[$index]c_date_of_birth" => ['type' => Form::INPUT_WIDGET, 'widgetClass' => '\kartik\widgets\DatePicker', 'hint' => '', 'options' => ['pluginOptions' => ['format' => 'yyyy-mm-dd', 'autoclose' => true, 'todayHighlight' => true]]],
                        "[$index]c_gender" => ['type' => Form::INPUT_DROPDOWN_LIST, 'items' => ['M' => 'Male', 'F' => 'Female'], 'options' => ['placeholder' => '', 'prompt' => 'Select..']],
                    ],
                ],
                [
                    'attributes' => [
                        "[$index]c_toilet_trained" => ['type' => Form::INPUT_WIDGET, 'widgetClass' => SwitchInput::className(), 'options' => ['pluginOptions' => ['onText' => 'Yes', 'offText' => 'No',],],],
                        "[$index]c_grade" => ['type' => Form::INPUT_DROPDOWN_LIST, 'items' => [1, 2, 3, 4, 5, 6, 7, 8], 'options' => ['placeholder' => '']],
                    ],
                ],
                [
                    'attributes' => [
                        "[$index]c_medical_conditions" => ['type' => Form::INPUT_WIDGET, 'widgetClass' => SwitchInput::className(), 'options' => [
                            'pluginOptions' => ['onText' => 'Yes', 'offText' => 'No',],
                            'pluginEvents' => ["switchChange.bootstrapSwitch" => "function(){}"]
                            ], 'label' => 'Allergies / Medical conditions:'],                        
                        "[$index]c_medical_condition_note" => ['type' => Form::INPUT_TEXTAREA, 'options' => ['placeholder' => ''], 'label' => 'If Yes, please comment:'],
                    ],
                ],
                [
                    'attributes' => [
                        "[$index]c_behavioural_issue" => ['type' => Form::INPUT_WIDGET, 'widgetClass' => SwitchInput::className(), 'options' => ['pluginOptions' => ['onText' => 'Yes', 'offText' => 'No',],], 'label' => 'Does your child have any behavioural / language issues:'],
                        "[$index]c_behavioural_note" => ['type' => Form::INPUT_TEXTAREA, 'options' => ['placeholder' => ''], 'label' => 'If Yes, please comment:'],
                    ],
                ],
            ]
        ]);
        ?>

    </div>
</div>